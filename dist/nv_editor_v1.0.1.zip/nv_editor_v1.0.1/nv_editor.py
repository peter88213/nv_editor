"""A multi-section "plain text" editor plugin for noveltree.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/noveltree_editor
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import sys
from tkinter import messagebox
import webbrowser

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import locale
import gettext

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_editor', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Section Editor')
PLUGIN = f'{APPLICATION} plugin v1.0.1'
ICON = 'eLogo32'
SECTION_PREFIX = 'sc'

from tkinter import messagebox
from tkinter import ttk

import re
import tkinter as tk
from tkinter import ttk
import xml.etree.ElementTree as ET


ADDITIONAL_WORD_LIMITS = re.compile('--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile('\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class TextBox(tk.Text):
    _TAGS = ('em', 'strong')

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def check_validity(self):
        xmlText = f'<a>{self.get("1.0", "end")}</a>'
        try:
            ET.fromstring(xmlText)
        except Exception as ex:
            issue, location = str(ex).split(':')
            lineStr = re.search('line ([0-9]+)', location).group(1)
            columnStr = re.search('column ([0-9]+)', location).group(1)
            column = int(columnStr) - 3
            self.mark_set('insert', f'{lineStr}.{column}')
            raise ValueError(f'{issue}: line {lineStr} column {column}')
            return False

        return True

    def get_text(self, start='1.0', end='end'):
        text = self.get(start, end)
        text = text.strip(' \n')
        text = text.replace('\n', '')
        return text

    def set_text(self, text):
        startIndex = len("<p>")
        if not text:
            text = '<p></p>'
        text = text.replace('</p>', '</p>\n')
        self.insert('end', text)
        self.edit_reset()
        self.mark_set('insert', f'1.{startIndex}')

    def count_words(self):
        text = self.get('1.0', 'end').replace('\n', '')
        text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
        text = NO_WORD_LIMITS.sub('', text)
        return len(text.split())

    def emphasis(self, event=None):
        self._set_format(tag='em')

    def strong_emphasis(self, event=None):
        self._set_format(tag='strong')

    def plain(self, event=None):
        self._set_format()

    def new_paragraph(self, event=None):
        self.insert('insert', '</p>\n<p>')
        return 'break'

    def _set_format(self, event=None, tag=''):
        if tag:
            if self.tag_ranges('sel'):
                text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
                if text.startswith(f'<{tag}>'):
                    if text.endswith(f'</{tag}>'):
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                text = self._remove_format(text, tag)
                self._replace_selected(f'<{tag}>{text}</{tag}>')
            else:
                self.insert('insert', f'<{tag}>')
                endTag = f'</{tag}>'
                self.insert('insert', endTag)
                self.mark_set('insert', f'insert-{len(endTag)}c')
        elif self.tag_ranges('sel'):
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            for tag in self._TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)

    def _replace_selected(self, text):
        self.mark_set('insert', tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _remove_format(self, text, tag):
        if tag in self._TAGS:
            finished = False
            while not finished:
                start = text.find(f'<{tag}>')
                if start >= 0:
                    end = text.find(f'</{tag}>')
                    if  start < end:
                        text = f'{text[:start]}{text[start + len(tag) +2:end]}{text[end + len(tag) + 3:]}'
                    else:
                        finished = True
                else:
                    finished = True
            return text

    def clear(self):
        self.delete('1.0', 'end')

HELP_URL = 'https://peter88213.github.io/noveltree_editor/usage'
KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')
KEY_APPLY_CHANGES = ('<Control-s>', 'Ctrl-S')
KEY_UPDATE_WORDCOUNT = ('<F5>', 'F5')
KEY_SPLIT_SCENE = ('<Control-Alt-s>', 'Ctrl-Alt-S')
KEY_CREATE_SCENE = ('<Control-Alt-n>', 'Ctrl-Alt-N')
KEY_ITALIC = ('<Control-i>', 'Ctrl-I')
KEY_BOLD = ('<Control-b>', 'Ctrl-B')
KEY_PLAIN = ('<Control-m>', 'Ctrl-M')

COLOR_MODES = [
    (_('Bright mode'), 'black', 'white'),
    (_('Light mode'), 'black', 'antique white'),
    (_('Dark mode'), 'light grey', 'gray20'),
    ]


class SectionEditor(tk.Toplevel):
    liveWordCount = False
    colorMode = 0

    def __init__(self, plugin, model, view, controller, scId, size, icon=None):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._plugin = plugin
        self._section = self._mdl.novel.sections[scId]
        self._scId = scId

        super().__init__()
        self.geometry(size)
        if icon:
            self.iconphoto(False, icon)

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        '''
        self._buttonBar = tk.Frame(self)
        self._buttonBar.pack(expand=False, fill='both')
        '''

        self._sectionEditor = TextBox(
            self,
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=self._plugin.kwargs['paragraph_spacing'],
            spacing2=self._plugin.kwargs['line_spacing'],
            maxundo=-1,
            padx=self._plugin.kwargs['margin_x'],
            pady=self._plugin.kwargs['margin_y'],
            font=(self._plugin.kwargs['font_family'], self._plugin.kwargs['font_size']),
            )
        self._sectionEditor.pack(expand=True, fill='both')
        self._sectionEditor.pack_propagate(0)
        self._set_editor_colors()

        self._statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self._statusBar.pack(expand=False, side='left')

        ttk.Button(self, text=_('Next'), command=self._load_next).pack(side='right')
        ttk.Button(self, text=_('Exit'), command=self.on_quit).pack(side='right')
        ttk.Button(self, text=_('Previous'), command=self._load_prev).pack(side='right')

        self._load_section()

        '''
        tk.Button(self._buttonBar, text=_('Copy'), command=lambda: self._sectionEditor.event_generate("<<Copy>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Cut'), command=lambda: self._sectionEditor.event_generate("<<Cut>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Paste'), command=lambda: self._sectionEditor.event_generate("<<Paste>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Italic'), command=self._sectionEditor.emphasis).pack(side='left')
        tk.Button(self._buttonBar, text=_('Bold'), command=self._sectionEditor.strong_emphasis).pack(side='left')
        '''

        self._fileMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Section'), menu=self._fileMenu)
        self._fileMenu.add_command(label=_('Next'), command=self._load_next)
        self._fileMenu.add_command(label=_('Previous'), command=self._load_prev)
        self._fileMenu.add_command(label=_('Apply changes'), accelerator=KEY_APPLY_CHANGES[1], command=self._apply_changes)
        self._fileMenu.add_command(label=_('Exit'), accelerator=KEY_QUIT_PROGRAM[1], command=self.on_quit)

        self._viewMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('View'), menu=self._viewMenu)
        self._viewMenu.add_command(label=COLOR_MODES[0][0], command=lambda: self._set_view_mode(mode=0))
        self._viewMenu.add_command(label=COLOR_MODES[1][0], command=lambda: self._set_view_mode(mode=1))
        self._viewMenu.add_command(label=COLOR_MODES[2][0], command=lambda: self._set_view_mode(mode=2))

        self._editMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Edit'), menu=self._editMenu)
        self._editMenu.add_command(label=_('Copy'), accelerator='Ctrl-C', command=lambda: self._sectionEditor.event_generate("<<Copy>>"))
        self._editMenu.add_command(label=_('Cut'), accelerator='Ctrl-X', command=lambda: self._sectionEditor.event_generate("<<Cut>>"))
        self._editMenu.add_command(label=_('Paste'), accelerator='Ctrl-V', command=lambda: self._sectionEditor.event_generate("<<Paste>>"))
        self._editMenu.add_separator()
        self._editMenu.add_command(label=_('Split at cursor position'), accelerator=KEY_SPLIT_SCENE[1], command=self._split_section)
        self._editMenu.add_command(label=_('Create section'), accelerator=KEY_CREATE_SCENE[1], command=self._create_section)

        self._formatMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Format'), menu=self._formatMenu)
        self._formatMenu.add_command(label=_('Emphasis'), accelerator=KEY_ITALIC[1], command=self._sectionEditor.emphasis)
        self._formatMenu.add_command(label=_('Strong emphasis'), accelerator=KEY_BOLD[1], command=self._sectionEditor.strong_emphasis)
        self._formatMenu.add_command(label=_('Plain'), accelerator=KEY_PLAIN[1], command=self._sectionEditor.plain)

        self._wcMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Word count'), menu=self._wcMenu)
        self._wcMenu.add_command(label=_('Update'), accelerator=KEY_UPDATE_WORDCOUNT[1], command=self.show_wordcount)
        self._wcMenu.add_command(label=_('Enable live update'), command=self._live_wc_on)
        self._wcMenu.add_command(label=_('Disable live update'), command=self._live_wc_off)

        self.helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), command=lambda: webbrowser.open(HELP_URL))

        self.bind_class('Text', KEY_APPLY_CHANGES[0], self._apply_changes)
        self.bind_class('Text', KEY_QUIT_PROGRAM[0], self.on_quit)
        self.bind_class('Text', KEY_UPDATE_WORDCOUNT[0], self.show_wordcount)
        self.bind_class('Text', KEY_SPLIT_SCENE[0], self._split_section)
        self.bind_class('Text', KEY_CREATE_SCENE[0], self._create_section)
        self.bind_class('Text', KEY_ITALIC[0], self._sectionEditor.emphasis)
        self.bind_class('Text', KEY_BOLD[0], self._sectionEditor.strong_emphasis)
        self.bind_class('Text', KEY_PLAIN[0], self._sectionEditor.plain)
        self.bind_class('Text', '<Return>', self._sectionEditor.new_paragraph)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        if SectionEditor.liveWordCount:
            self._live_wc_on()
        else:
            self._wcMenu.entryconfig(_('Disable live update'), state='disabled')

        self.lift()
        self.isOpen = True

    def lift(self):
        super().lift()
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

    def show_status(self, message=None):
        self._statusBar.config(text=message)

    def show_wordcount(self, event=None):
        wc = self._sectionEditor.count_words()
        diff = wc - self._initialWc
        self._statusBar.config(text=f'{wc} {_("words")} ({diff} {_("new")})')

    def _create_section(self, event=None):
        if self._ctrl.isLocked:
            messagebox.showinfo(APPLICATION, _('Cannot create sections, because the project is locked.'), parent=self)
            self.lift()
            return

        self.lift()
        thisNode = self._scId
        newId = self._ctrl.add_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scPacing=self._mdl.novel.sections[self._scId].scPacing,
            )
        self._load_next()

    def _apply_changes(self, event=None):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._transfer_text(sectionText)

    def _apply_changes_after_asking(self, event=None):
        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if messagebox.askyesno(APPLICATION, _('Apply section changes?'), parent=self):
                    try:
                        self._sectionEditor.check_validity()
                    except ValueError as ex:
                        self._ui.show_warning(str(ex))
                        self.lift()
                        return False

                    self._transfer_text(sectionText)
        return True

    def _live_wc_off(self, event=None):
        self.unbind('<KeyRelease>')
        self._wcMenu.entryconfig(_('Enable live update'), state='normal')
        self._wcMenu.entryconfig(_('Disable live update'), state='disabled')
        SectionEditor.liveWordCount = False

    def _live_wc_on(self, event=None):
        self.bind('<KeyRelease>', self.show_wordcount)
        self._wcMenu.entryconfig(_('Enable live update'), state='disabled')
        self._wcMenu.entryconfig(_('Disable live update'), state='normal')
        self.show_wordcount()
        SectionEditor.liveWordCount = True

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self._scId = nextNode
            self._section = self._mdl.novel.sections[nextNode]
            self._sectionEditor.clear()
            self._load_section()
        self.lift()

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self._scId = prevNode
            self._section = self._mdl.novel.sections[prevNode]
            self._sectionEditor.clear()
            self._load_section()
        self.lift()

    def _load_section(self):
        self.title(f'{self._section.title} - {self._mdl.novel.title}, {_("Section")} ID {self._scId}')
        self._sectionEditor.set_text(self._section.sectionContent)
        self._initialWc = self._sectionEditor.count_words()
        self.show_wordcount()

    def _set_editor_colors(self):
        self._sectionEditor['fg'] = COLOR_MODES[SectionEditor.colorMode][1]
        self._sectionEditor['bg'] = COLOR_MODES[SectionEditor.colorMode][2]
        self._sectionEditor['insertbackground'] = COLOR_MODES[SectionEditor.colorMode][1]

    def _set_view_mode(self, event=None, mode=0):
        SectionEditor.colorMode = mode
        self._set_editor_colors()

    def _split_section(self, event=None):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        if self._ctrl.isLocked:
            messagebox.showinfo(APPLICATION, _('Cannot split the section, because the project is locked.'), parent=self)
            self.lift()
            return

        if not messagebox.askyesno(APPLICATION, f'{_("Move the text from the cursor position to the end into a new section")}?', parent=self):
            self.lift()
            return

        self.lift()
        thisNode = self._scId
        newId = self._ctrl.add_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scPacing=self._mdl.novel.sections[self._scId].scPacing,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:
            newContent = self._sectionEditor.get_text('insert', 'end').strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            if self._mdl.novel.sections[self._scId].characters:
                viewpoint = self._mdl.novel.sections[self._scId].characters[0]
                self._mdl.novel.sections[newId].characters = [viewpoint]

            self._load_next()

    def _transfer_text(self, sectionText):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        if self._ctrl.isLocked:
            if messagebox.askyesno(APPLICATION, _('Cannot apply section changes, because the project is locked.\nUnlock and apply changes?'), parent=self):
                self._ctrl.unlock()
                self._section.sectionContent = sectionText
            self.lift()
        else:
            self._section.sectionContent = sectionText
        self._ui.show_status()


SETTINGS = dict(
        window_geometry='600x800',
        color_mode=0,
        color_fg_bright='white',
        color_bg_bright='black',
        color_fg_light='antique white',
        color_bg_light='black',
        color_fg_dark='light grey',
        color_bg_dark='gray20',
        font_family='Courier',
        font_size=12,
        line_spacing=6,
        paragraph_spacing=18,
        margin_x=40,
        margin_y=20,
        )
OPTIONS = dict(
        live_wordcount=False,
        )


class Plugin:
    VERSION = '1.0.1'
    NOVELTREE_API = '1.0'
    DESCRIPTION = 'A multi-section "plain text" editor'
    URL = 'https://peter88213.github.io/noveltree_editor'
    _HELP_URL = 'https://peter88213.github.io/noveltree_editor/usage'

    def install(self, model, view, controller, prefs):
        """Add a submenu to the main menu.
        
        Positional arguments:
            controller -- reference to the main controller instance of the application.
            view -- reference to the main view instance of the application.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.noveltree/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/editor.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.sectionMenu.add_separator()
        self._ui.sectionMenu.add_command(label=_('Edit'), underline=0, command=self.open_node)

        self._ui.helpMenu.add_command(label=_('Editor plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

        self.sectionEditors = {}
        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self._icon = tk.PhotoImage(file=f'{path}/icons/{ICON}.png')
        except:
            self._icon = None

        SectionEditor.colorMode = int(self.kwargs['color_mode'])
        SectionEditor.liveWordCount = self.kwargs['live_wordcount']

    def open_node(self, event=None):
        try:
            nodeId = self._ui.tv.tree.selection()[0]
            if nodeId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[nodeId].scType > 1:
                    return

                if self._ctrl.isLocked:
                    messagebox.showinfo(APPLICATION, _('Cannot edit sections, because the project is locked.'))
                    return

                if nodeId in self.sectionEditors and self.sectionEditors[nodeId].isOpen:
                    self.sectionEditors[nodeId].lift()
                    return

                self.sectionEditors[nodeId] = SectionEditor(self, self._mdl, self._ui, self._ctrl, nodeId, self.kwargs['window_geometry'], icon=self._icon)

        except IndexError:
            pass

    def on_close(self, event=None):
        """Actions to be performed when a project is closed.
        
        Close all open section editor windows. 
        """
        for scId in self.sectionEditors:
            if self.sectionEditors[scId].isOpen:
                self.sectionEditors[scId].on_quit()

    def on_quit(self, event=None):
        self.on_close()

        self.kwargs['color_mode'] = SectionEditor.colorMode
        self.kwargs['live_wordcount'] = SectionEditor.liveWordCount
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

