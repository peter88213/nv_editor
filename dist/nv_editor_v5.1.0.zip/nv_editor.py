"""A multi-section "plain text" editor plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_editor
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import sys



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass
from tkinter import ttk

import re
from tkinter import ttk



def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)

import tkinter as tk
import xml.etree.ElementTree as ET

ADDITIONAL_WORD_LIMITS = re.compile(r'--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class EditorBox(tk.Text):
    _TAGS = ('em', 'strong')
    XML_TAG = 'xmlTag'
    COLOR_XML_TAG = 'cornflower blue'

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self.tag_configure(self.XML_TAG,
                           foreground=self.COLOR_XML_TAG,
                           )

    def check_validity(self):
        text = strip_illegal_characters(self.get("1.0", "end"))
        xmlText = f'<a>{text}</a>'
        try:
            ET.fromstring(xmlText)
        except Exception as ex:
            issue, location = str(ex).split(':')
            lineStr = re.search(r'line ([0-9]+)', location).group(1)
            columnStr = re.search(r'column ([0-9]+)', location).group(1)
            column = int(columnStr) - 3
            self.mark_set('insert', f'{lineStr}.{column}')
            raise ValueError(f'{issue}: line {lineStr} column {column}')
            return False

        return True

    def clear(self):
        self.delete('1.0', 'end')

    def get_text(self, start='1.0', end='end'):
        text = self.get(start, end)
        text = text.strip(' \n')
        text = text.replace('\n', '')
        return strip_illegal_characters(text)

    def colorize(self, event=None):
        self.tag_remove(self.XML_TAG, '1.0', 'end')
        for i in range(int(self.index('end').split('.')[0])):
            line = self.get(f'{i}.0', f'{i}.0 lineend')
            for xmlTag in re.finditer('<.*?>', line):
                self.tag_add(self.XML_TAG, f'{i}.{xmlTag.start()}', f'{i}.{xmlTag.end()}')

    def set_text(self, text):
        startIndex = len("<p>")
        if not text:
            text = '<p></p>'
        text = text.replace('</p>', '</p>\n')
        self.insert('end', text)
        self.edit_reset()
        self.mark_set('insert', f'1.{startIndex}')
        self.colorize()

    def count_words(self):
        text = self.get('1.0', 'end')
        text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
        text = NO_WORD_LIMITS.sub('', text)
        return len(text.split())

    def emphasis(self, event=None):
        self._set_format(tag='em')
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag='strong')
        return 'break'

    def plain(self, event=None):
        self._set_format()
        return 'break'

    def new_paragraph(self, event=None):
        self.insert('insert', '</p>\n<p>')
        self.colorize()
        return 'break'

    def _convert_from_novx(self, text, textTag, update):
        self._contentParser.textTag = textTag
        self._contentParser.update = update
        self._contentParser.feed(text)
        return self._contentParser.taggedText[1:-1]

    def _set_format(self, event=None, tag=''):
        if tag:
            if self.tag_ranges('sel'):
                text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
                if text.startswith(f'<{tag}>'):
                    if text.endswith(f'</{tag}>'):
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                text = self._remove_format(text, tag)
                self._replace_selected(f'<{tag}>{text}</{tag}>')
            else:
                self.insert('insert', f'<{tag}>')
                endTag = f'</{tag}>'
                self.insert('insert', endTag)
                self.mark_set('insert', f'insert-{len(endTag)}c')
        elif self.tag_ranges('sel'):
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            for tag in self._TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)
        self.colorize()

    def _replace_selected(self, text):
        self.mark_set('insert', tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _remove_format(self, text, tag):
        if tag in self._TAGS:
            finished = False
            while not finished:
                start = text.find(f'<{tag}>')
                if start >= 0:
                    end = text.find(f'</{tag}>')
                    if  start < end:
                        text = f'{text[:start]}{text[start + len(tag) +2:end]}{text[end + len(tag) + 3:]}'
                    else:
                        finished = True
                else:
                    finished = True
            return text

import gettext
import locale

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_editor', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


FEATURE = _('Section Editor')
ICON = 'eLogo32'

import webbrowser



class NveditorHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_editor/'

    @classmethod
    def open_help_page(cls):
        webbrowser.open(cls.HELP_URL)



class EditorViewCtrl(SubController):
    liveWordCount = None
    colorMode = None

    def initialize_controller(self, model, view, controller, scId, service):
        super().initialize_controller(model, view, controller)
        self._section = self._mdl.novel.sections[scId]
        self._scId = scId
        self.service = service

    def open_help(self, event=None):
        NveditorHelp.open_help_page()

    def show_wordcount(self, event=None):
        wc = self.sectionEditor.count_words()
        diff = wc - self._initialWc
        self._statusBar.config(text=f'{wc} {_("words")} ({diff} {_("new")})')

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        try:
            self.sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                str(ex),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        sectionText = self.sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._transfer_text(sectionText)

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self.sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if self._ui.ask_yes_no(
                    _('Apply section changes?'),
                    title=FEATURE,
                    parent=self
                    ):
                    try:
                        self.sectionEditor.check_validity()
                    except ValueError as ex:
                        self._ui.show_error(
                            str(ex),
                            title=FEATURE,
                            parent=self
                            )
                        self.lift()
                        return False

                    self._transfer_text(sectionText)
        return True

    def _create_section(self, event=None):
        if self._ctrl.isLocked:
            self._ui.show_info(
                _('Cannot create sections, because the project is locked.'),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        self.lift()
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        return newId

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self.service.close_editor_window(self._scId)
            self.service.open_editor_window()

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self.service.close_editor_window(self._scId)
            self.service.open_editor_window()

    def _load_section(self):
        self.title(f'{self._section.title} - {self._mdl.novel.title}, {_("Section")} ID {self._scId}')
        self.sectionEditor.set_text(self._section.sectionContent)
        self._initialWc = self.sectionEditor.count_words()
        self.show_wordcount()

    def _split_section(self, event=None):

        try:
            self.sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                str(ex),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        if self._ctrl.isLocked:
            self._ui.show_info(
                _('Cannot split the section, because the project is locked.'),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        try:
            ET.fromstring(f"<a>{self.sectionEditor.get('1.0', 'insert')}</a>")
            ET.fromstring(f"<a>{self.sectionEditor.get('insert', 'end')}</a>")
        except:
            self._ui.show_error(
                _('Cannot split the section at the cursor position.'),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        if self._ui.ask_yes_no(
            f'{_("Move the text from the cursor position to the end into a new section")}?',
            title=FEATURE,
            parent=self
            ):
            self.lift()
        else:
            self.lift()
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self.sectionEditor.get_text('insert', 'end').strip(' \n')
            self.sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            if self._mdl.novel.sections[self._scId].characters:
                viewpoint = self._mdl.novel.sections[self._scId].characters[0]
                self._mdl.novel.sections[newId].characters = [viewpoint]

            self._load_next()

    def _transfer_text(self, sectionText):
        try:
            self.sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                str(ex),
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        if self._ctrl.isLocked:
            if self._ui.ask_yes_no(
                _('Cannot apply section changes, because the project is locked.\nUnlock and apply changes?'),
                title=FEATURE,
                parent=self
                ):
                self._ctrl.unlock()
                self._section.sectionContent = sectionText
            self.lift()
        else:
            self._section.sectionContent = sectionText

import platform



class GenericKeys:

    APPLY_CHANGES = ('<Control-s>', f'{_("Ctrl")}-S')
    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SCENE = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    OPEN_HELP = ('<F1>', 'F1')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SPLIT_SCENE = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')


class MacKeys(GenericKeys):

    APPLY_CHANGES = ('<Command-s>', 'Cmd-S')
    BOLD = ('<Command-b>', 'Cmd-B')
    CREATE_SCENE = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ITALIC = ('<Command-i>', 'Cmd-I')
    PLAIN = ('<Command-m>', 'Cmd-M')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SPLIT_SCENE = ('<Command-Alt-s>', 'Cmd-Alt-S')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()



class EditorView(tk.Toplevel, EditorViewCtrl):
    liveWordCount = None
    colorMode = None

    def __init__(self, model, view, controller, scId, service, icon=None):
        self.initialize_controller(model, view, controller, scId, service)
        self.prefs = service.prefs

        self.colorModes = [
            (
                _('Bright mode'),
                self.prefs['color_fg_bright'],
                self.prefs['color_bg_bright'],
                ),
            (
                _('Light mode'),
                self.prefs['color_fg_light'],
                self.prefs['color_bg_light'],
                ),
            (
                _('Dark mode'),
                self.prefs['color_fg_dark'],
                self.prefs['color_bg_dark'],
                ),
            ]

        super().__init__()
        self.geometry(self.prefs['win_geometry'])
        if icon:
            self.iconphoto(False, icon)

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        '''
        self._buttonBar = ttk.Frame(self)
        self._buttonBar.pack(expand=False, fill='both')
        '''

        self.sectionEditor = EditorBox(
            self,
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=self.prefs['paragraph_spacing'],
            spacing2=self.prefs['line_spacing'],
            maxundo=-1,
            padx=self.prefs['margin_x'],
            pady=self.prefs['margin_y'],
            font=(self.prefs['font_family'], self.prefs['font_size']),
            )
        self.sectionEditor.pack(expand=True, fill='both')
        self.sectionEditor.pack_propagate(0)
        self._set_editor_colors()

        self._statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self._statusBar.pack(expand=False, side='left')

        ttk.Button(self, text=_('Next'), command=self._load_next).pack(side='right')
        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right')
        ttk.Button(self, text=_('Previous'), command=self._load_prev).pack(side='right')

        self._load_section()

        '''
        tk.Button(self._buttonBar, text=_('Copy'), command=lambda: self._sectionEditor.event_generate("<<Copy>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Cut'), command=lambda: self._sectionEditor.event_generate("<<Cut>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Paste'), command=lambda: self._sectionEditor.event_generate("<<Paste>>")).pack(side='left')
        tk.Button(self._buttonBar, text=_('Italic'), command=self._sectionEditor.emphasis).pack(side='left')
        tk.Button(self._buttonBar, text=_('Bold'), command=self._sectionEditor.strong_emphasis).pack(side='left')
        '''

        self._sectionMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Section'), menu=self._sectionMenu)
        self._sectionMenu.add_command(label=_('Next'), command=self._load_next)
        self._sectionMenu.add_command(label=_('Previous'), command=self._load_prev)
        self._sectionMenu.add_command(label=_('Apply changes'), accelerator=KEYS.APPLY_CHANGES[1], command=self._apply_changes)
        if PLATFORM == 'win':
            self._sectionMenu.add_command(label=_('Exit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)
        else:
            self._sectionMenu.add_command(label=_('Quit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)

        self._viewMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('View'), menu=self._viewMenu)
        for i, cm in enumerate(self.colorModes):
            self._viewMenu.add_radiobutton(label=cm[0], variable=EditorView.colorMode, command=self._set_editor_colors, value=i)

        self._editMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Edit'), menu=self._editMenu)
        self._editMenu.add_command(label=_('Copy'), accelerator=KEYS.COPY[1], command=lambda: self.sectionEditor.event_generate("<<Copy>>"))
        self._editMenu.add_command(label=_('Cut'), accelerator=KEYS.CUT[1], command=lambda: self.sectionEditor.event_generate("<<Cut>>"))
        self._editMenu.add_command(label=_('Paste'), accelerator=KEYS.PASTE[1], command=lambda: self.sectionEditor.event_generate("<<Paste>>"))
        self._editMenu.add_separator()
        self._editMenu.add_command(label=_('Split at cursor position'), accelerator=KEYS.SPLIT_SCENE[1], command=self._split_section)
        self._editMenu.add_command(label=_('Create section'), accelerator=KEYS.CREATE_SCENE[1], command=self._create_section)

        self._formatMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Format'), menu=self._formatMenu)
        self._formatMenu.add_command(label=_('Emphasis'), accelerator=KEYS.ITALIC[1], command=self.sectionEditor.emphasis)
        self._formatMenu.add_command(label=_('Strong emphasis'), accelerator=KEYS.BOLD[1], command=self.sectionEditor.strong_emphasis)
        self._formatMenu.add_command(label=_('Plain'), accelerator=KEYS.PLAIN[1], command=self.sectionEditor.plain)

        self._wcMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Word count'), menu=self._wcMenu)
        self._wcMenu.add_command(label=_('Update'), accelerator=KEYS.UPDATE_WORDCOUNT[1], command=self.show_wordcount)
        self._wcMenu.add_checkbutton(label=_('Live update'), variable=EditorView.liveWordCount, command=self._set_wc_mode)

        self.helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator=KEYS.OPEN_HELP[1], command=self.open_help)

        self.bind(KEYS.OPEN_HELP[0], self.open_help)
        if PLATFORM != 'win':
            self.sectionEditor.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self.sectionEditor.bind(KEYS.APPLY_CHANGES[0], self._apply_changes)
        self.sectionEditor.bind(KEYS.UPDATE_WORDCOUNT[0], self.show_wordcount)
        self.sectionEditor.bind('<space>', self.sectionEditor.colorize)
        self.sectionEditor.bind(KEYS.SPLIT_SCENE[0], self._split_section)
        self.sectionEditor.bind(KEYS.CREATE_SCENE[0], self._create_section)
        self.sectionEditor.bind(KEYS.ITALIC[0], self.sectionEditor.emphasis)
        self.sectionEditor.bind(KEYS.BOLD[0], self.sectionEditor.strong_emphasis)
        self.sectionEditor.bind(KEYS.PLAIN[0], self.sectionEditor.plain)
        self.sectionEditor.bind('<Return>', self.sectionEditor.new_paragraph)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._set_wc_mode()
        self.lift()
        self.isOpen = True

    def lift(self):
        if self.state() == 'iconic':
            self.state('normal')
        super().lift()
        self.sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        self.prefs['win_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

    def _set_editor_colors(self):
        cm = EditorView.colorMode.get()
        self.sectionEditor['fg'] = self.colorModes[cm][1]
        self.sectionEditor['bg'] = self.colorModes[cm][2]
        self.sectionEditor['insertbackground'] = self.colorModes[cm][1]

    def _set_wc_mode(self, *args):
        if EditorView.liveWordCount.get():
            self.bind('<KeyRelease>', self.show_wordcount)
            self.show_wordcount()
        else:
            self.unbind('<KeyRelease>')

    def show_status(self, message=None):
        self._statusBar.config(text=message)

from datetime import date
from datetime import time

import calendar

try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = calendar.day_name
MONTHS = calendar.month_name


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
MINOR_MARKER = _('Minor Character')
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



class EditorService(SubController, Observer):
    INI_FILENAME = 'editor.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        win_geometry='600x800',
        color_mode=0,
        color_bg_bright='white',
        color_fg_bright='black',
        color_bg_light='antique white',
        color_fg_light='black',
        color_bg_dark='gray20',
        color_fg_dark='light grey',
        font_family='Courier',
        font_size=12,
        line_spacing=4,
        paragraph_spacing=4,
        margin_x=40,
        margin_y=20,
    )
    OPTIONS = dict(
        live_wordcount=False,
    )

    def __init__(self, model, view, controller):
        super().initialize_controller(model, view, controller)

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)

        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self.icon = tk.PhotoImage(file=f'{path}/icons/{ICON}.png')
        except:
            self.icon = None

        self._mdl.add_observer(self)

        EditorView.colorMode = tk.IntVar(
            value=int(self.prefs['color_mode'])
            )
        EditorView.liveWordCount = tk.BooleanVar(
            value=self.prefs['live_wordcount']
            )

        self.sectionEditors = {}

    def close_editor_window(self, nodeId):
        if nodeId in self.sectionEditors and self.sectionEditors[nodeId].isOpen:
            self.sectionEditors[nodeId].on_quit()
            del self.sectionEditors[nodeId]

    def on_close(self):
        for scId in self.sectionEditors:
            if self.sectionEditors[scId].isOpen:
                self.sectionEditors[scId].on_quit()

    def on_quit(self):
        self.on_close()
        self.prefs['color_mode'] = EditorView.colorMode.get()
        self.prefs['live_wordcount'] = EditorView.liveWordCount.get()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write(self.iniFile)

    def open_editor_window(self):
        try:
            nodeId = self._ui.selectedNode
            if nodeId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[nodeId].scType > 1:
                    return

                if self._ctrl.isLocked:
                    self._ui.show_info(_('Cannot edit sections, because the project is locked.'), title=FEATURE)
                    return

                if nodeId in self.sectionEditors and self.sectionEditors[nodeId].isOpen:
                    self.sectionEditors[nodeId].lift()
                    return

                self.sectionEditors[nodeId] = EditorView(
                    self._mdl,
                    self._ui,
                    self._ctrl,
                    nodeId,
                    self,
                    icon=self.icon
                    )

        except IndexError:
            pass

    def refresh(self):
        for scId in list(self.sectionEditors):
            if not scId in self._mdl.novel.sections:
                self.sectionEditors[scId].on_quit()
                del self.sectionEditors[scId]
from abc import ABC, abstractmethod



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)



class Plugin(PluginBase):
    VERSION = '5.1.0'
    API_VERSION = '5.0'
    DESCRIPTION = 'A multi-section "plain text" editor'
    URL = 'https://github.com/peter88213/nv_editor'

    def install(self, model, view, controller):
        """Add a submenu to the main menu.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.editorService = EditorService(model, view, controller)

        self._ui.sectionMenu.add_separator()
        self._ui.sectionMenu.add_command(label=_('Edit'), underline=0, command=self.open_editor_window)

        self._ui.helpMenu.add_command(label=_('Editor plugin Online help'), command=self.open_help)

        self._ui.tv.tree.bind('<Double-1>', self.open_editor_window)
        self._ui.tv.tree.bind('<Return>', self.open_editor_window)

    def on_close(self, event=None):
        """Actions to be performed when a project is closed.
        
        Close all open section editor windows. 
        Overrides the superclass method.
        """
        self.editorService.on_close()

    def on_quit(self, event=None):
        """Actions to be performed when novelibre is closed.
        
        Overrides the superclass method.
        """
        self.editorService.on_quit()

    def open_editor_window(self, event=None):
        self.editorService.open_editor_window()

    def open_help(self, event=None):
        NveditorHelp.open_help_page()

