"""A multi-section "plain text" editor plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_editor
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_editor',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from pathlib import Path

import re
from tkinter import font as tkFont
from tkinter import ttk



def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)

import tkinter as tk
import xml.etree.ElementTree as ET


class EditorBox(tk.Text):
    _TAGS = ('em', 'strong')
    XML_TAG = 'xmlTag'

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        defaultFont = tkFont.Font(
            root=self,
            font=kw['font'],
            name='editor_font',
        )
        boldFont = tkFont.Font(**defaultFont.configure())
        boldFont.configure(weight='bold')

        text_meths = vars(tk.Text).keys()
        methods = (
            vars(tk.Pack).keys()
            | vars(tk.Grid).keys()
            | vars(tk.Place).keys()
        )
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        self.tag_configure(
            self.XML_TAG,
            foreground='cornflower blue',
            font=boldFont,
        )

    def check_validity(self):
        text = strip_illegal_characters(self.get("1.0", "end"))
        xmlText = f'<a>{text}</a>'
        try:
            ET.fromstring(xmlText)
        except Exception as ex:
            issue, location = str(ex).split(':')
            lineStr = re.search(r'line ([0-9]+)', location).group(1)
            columnStr = re.search(r'column ([0-9]+)', location).group(1)
            column = int(columnStr) - 3
            self.mark_set('insert', f'{lineStr}.{column}')
            raise ValueError(f'{issue}: line {lineStr} column {column}')
            return False

        return True

    def clear(self):
        self.delete('1.0', 'end')

    def get_text(self, start='1.0', end='end'):
        text = self.get(start, end)
        text = text.strip(' \n')
        text = text.replace('\n', '')
        return strip_illegal_characters(text)

    def colorize(self, event=None):
        self.tag_remove(self.XML_TAG, '1.0', 'end')
        for i in range(int(self.index('end').split('.')[0])):
            line = self.get(f'{i}.0', f'{i}.0 lineend')
            for xmlTag in re.finditer('<.*?>', line):
                self.tag_add(
                    self.XML_TAG,
                    f'{i}.{xmlTag.start()}',
                    f'{i}.{xmlTag.end()}',
                )

    def set_text(self, text):
        startIndex = len("<p>")
        if not text:
            text = '<p></p>'
        for tag in ('p', 'h5', 'h6', 'h7', 'h8', 'h9'):
            text = text.replace(f'</{tag}>', f'</{tag}>\n')
        self.insert('end', text)
        self.edit_reset()
        self.mark_set('insert', f'1.{startIndex}')
        self.colorize()

    def emphasis(self, event=None):
        self._set_format(tag='em')
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag='strong')
        return 'break'

    def plain(self, event=None):
        self._set_format()
        return 'break'

    def new_paragraph(self, event=None):
        self.insert('insert', '</p>\n<p>')
        self.colorize()
        return 'break'

    def _set_format(self, event=None, tag=''):
        if tag:
            if self.tag_ranges('sel'):
                text = self.get('sel.first', 'sel.last')
                if text.startswith(f'<{tag}>'):
                    if text.endswith(f'</{tag}>'):
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                text = self._remove_format(text, tag)
                self._replace_selected(f'<{tag}>{text}</{tag}>')
            else:
                self.insert('insert', f'<{tag}>')
                endTag = f'</{tag}>'
                self.insert('insert', endTag)
                self.mark_set('insert', f'insert-{len(endTag)}c')
        elif self.tag_ranges('sel'):
            text = self.get('sel.first', 'sel.last')
            for tag in self._TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)
        self.colorize()

    def _replace_selected(self, text):
        self.mark_set('insert', 'sel.first')
        self.delete('sel.first', 'sel.last')
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _remove_format(self, text, tag):
        if tag in self._TAGS:
            finished = False
            while not finished:
                start = text.find(f'<{tag}>')
                if start >= 0:
                    end = text.find(f'</{tag}>')
                    if  start < end:
                        text = (
                            f'{text[:start]}{text[start + len(tag) +2:end]}'
                            f'{text[end + len(tag) + 3:]}'
                        )
                    else:
                        finished = True
                else:
                    finished = True
            return text

from tkinter import ttk

from tkinter import font as tkFont


prefs = {}

FEATURE = _('Section Editor')
ICON = 'editor'
DEFAULT_FONT = 'Courier'
import webbrowser



class NveditorHelp:

    HELP_URL = f'{_("https://peter88213.github.io/nvhelp-en")}/nv_editor/'

    @classmethod
    def open_help_page(cls):
        webbrowser.open(cls.HELP_URL)

import platform



class GenericKeys:

    APPLY_CHANGES = ('<Control-s>', f'{_("Ctrl")}-S')
    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SECTION = ('<Control-n>', f'{_("Ctrl")}-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    NEXT = ('<Control-Next>', f'{_("Ctrl")}-{_("PgDn")}')
    OPEN_HELP = ('<F1>', 'F1')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    PREVIOUS = ('<Control-Prior>', f'{_("Ctrl")}-{_("PgUp")}')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    SPLIT_SECTION = ('<Control-l>', f'{_("Ctrl")}-L')
    START_EDITOR = ('<F4>', 'F4')


class LinuxKeys(GenericKeys):

    NEXT_KP = ('<Control-KP_Next>', f'{_("Ctrl")}-{_("PgDn")}')
    PREVIOUS_KP = ('<Control-KP_Prior>', f'{_("Ctrl")}-{_("PgUp")}')


class MacKeys(GenericKeys):

    APPLY_CHANGES = ('<Command-s>', 'Cmd-S')
    BOLD = ('<Command-b>', 'Cmd-B')
    CREATE_SECTION = ('<Command-n>', 'Cmd-N')
    ITALIC = ('<Command-i>', 'Cmd-I')
    NEXT = ('<Command-Next>', f'Cmd-{_("PgDn")}')
    PLAIN = ('<Command-m>', 'Cmd-M')
    PREVIOUS = ('<Command-Prior>', f'Cmd-{_("PgUp")}')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    SPLIT_SECTION = ('<Command-l>', 'Cmd-L')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = LinuxKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class EditorView(tk.Toplevel, SubController):
    colorModeVar = None

    COLOR_MODES = [
        (
            _('Bright mode'),
            'black',
            'white',
            'blue',
        ),
        (
            _('Light mode'),
            'black',
            'antique white',
            'firebrick',
        ),
        (
            _('Dark mode'),
            'light grey',
            'gray20',
            'gold',
        ),
        (
            _('Blue mode'),
            '#FFFFFF',
            '#0000AA',
            '#FFFF55',
        ),
    ]

    def __init__(self, model, view, controller, scId, service, icon=None):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._scId = scId
        self._service = service
        self._section = self._mdl.novel.sections[scId]

        super().__init__()
        self.geometry(prefs['win_geometry'])
        if icon:
            self.iconphoto(False, icon)

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        self._sectionEditor = EditorBox(
            self,
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=prefs['paragraph_spacing'],
            spacing2=prefs['line_spacing'],
            maxundo=-1,
            padx=prefs['margin_x'],
            pady=prefs['margin_y'],
            font=(
                prefs['editor_font'],
                prefs['font_size'],
            ),
        )
        self._sectionEditor.pack(expand=True, fill='both')
        self._sectionEditor.pack_propagate(0)
        self._set_editor_colors()

        self._statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self._statusBar.pack(expand=False, side='left')

        ttk.Button(
            self,
            text=_('Next'),
            command=self._load_next,
        ).pack(side='right')
        ttk.Button(
            self,
            text=_('Close'),
            command=self._request_closing,
        ).pack(side='right')
        ttk.Button(
            self,
            text=_('Previous'),
            command=self._load_prev,
        ).pack(side='right')

        self._load_section()


        self._sectionMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Section'),
            menu=self._sectionMenu,
        )
        self._sectionMenu.add_command(
            label=_('New'),
            accelerator=KEYS.CREATE_SECTION[1],
            command=self._create_section,
        )
        self._sectionMenu.add_command(
            label=_('Split'),
            accelerator=KEYS.SPLIT_SECTION[1],
            command=self._split_section,
        )
        self._sectionMenu.add_separator()
        self._sectionMenu.add_command(
            label=_('Previous'),
            accelerator=KEYS.PREVIOUS[1],
            command=self._load_prev,
        )
        self._sectionMenu.add_command(
            label=_('Next'),
            accelerator=KEYS.NEXT[1],
            command=self._load_next,
        )
        self._sectionMenu.add_separator()
        self._sectionMenu.add_command(
            label=_('Apply changes'),
            accelerator=KEYS.APPLY_CHANGES[1],
            command=self._apply_changes,
        )
        if PLATFORM == 'win':
            self._sectionMenu.add_command(
                label=_('Exit'),
                accelerator=KEYS.QUIT_PROGRAM[1],
                command=self._request_closing,
            )
        else:
            self._sectionMenu.add_command(
                label=_('Quit'),
                accelerator=KEYS.QUIT_PROGRAM[1],
                command=self._request_closing,
            )

        self._viewMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('View'),
            menu=self._viewMenu,
        )
        for i, cm in enumerate(self.COLOR_MODES):
            self._viewMenu.add_radiobutton(
                label=cm[0],
                variable=EditorView.colorModeVar,
                command=self._change_editor_colors,
                value=i,
            )

        self._editMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Edit'),
            menu=self._editMenu,
        )
        self._editMenu.add_command(
            label=_('Cut'), accelerator=KEYS.CUT[1],
            command=lambda: self._sectionEditor.event_generate("<<Cut>>"),
        )
        self._editMenu.add_command(
            label=_('Copy'),
            accelerator=KEYS.COPY[1],
            command=lambda: self._sectionEditor.event_generate("<<Copy>>"),
        )
        self._editMenu.add_command(
            label=_('Paste'),
            accelerator=KEYS.PASTE[1],
            command=lambda: self._sectionEditor.event_generate("<<Paste>>"),
        )

        self._formatMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Format'),
            menu=self._formatMenu,
        )
        self._formatMenu.add_command(
            label=_('Emphasis'),
            accelerator=KEYS.ITALIC[1],
            command=self._sectionEditor.emphasis,
        )
        self._formatMenu.add_command(
            label=_('Strong emphasis'),
            accelerator=KEYS.BOLD[1],
            command=self._sectionEditor.strong_emphasis,
        )
        self._formatMenu.add_command(
            label=_('Plain'),
            accelerator=KEYS.PLAIN[1],
            command=self._sectionEditor.plain,
        )

        self._helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Help'),
            menu=self._helpMenu,
        )
        self._helpMenu.add_command(
            label=_('Online help'),
            accelerator=KEYS.OPEN_HELP[1],
            command=self._open_help,
        )

        keyBindings = [
            (KEYS.OPEN_HELP[0], self._open_help),
            (KEYS.QUIT_PROGRAM[0], self._request_closing),
            (KEYS.APPLY_CHANGES[0], self._apply_changes),
            ('<space>', self._sectionEditor.colorize),
            (KEYS.SPLIT_SECTION[0], self._split_section),
            (KEYS.CREATE_SECTION[0], self._create_section),
            (KEYS.ITALIC[0], self._sectionEditor.emphasis),
            (KEYS.BOLD[0], self._sectionEditor.strong_emphasis),
            (KEYS.PLAIN[0], self._sectionEditor.plain),
            ('<Return>', self._sectionEditor.new_paragraph),
            (KEYS.NEXT[0], self._load_next),
            (KEYS.PREVIOUS[0], self._load_prev),
        ]
        if PLATFORM == 'ix':
            keyBindings.extend(
                [
                    (KEYS.NEXT_KP[0], self._load_next),
                    (KEYS.PREVIOUS_KP[0], self._load_prev),
                ]
            )
        for key, callback in keyBindings:
            self._sectionEditor.bind(key, callback)

        self.protocol("WM_DELETE_WINDOW", self._request_closing)

        self.lift()
        self.update_idletasks()
        self.geometry(prefs['win_geometry'])
        self.isOpen = True

    def lift(self):
        if self.state() == 'iconic':
            self.state('normal')
        super().lift()
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        prefs['win_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                message=_('Invalid changes'),
                detail=str(ex),
                parent=self
            )
            self.lift()
            return

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._transfer_text(sectionText)

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if self._ui.ask_yes_no(
                    message=_('Apply section changes?'),
                    title=FEATURE,
                    parent=self
                ):
                    try:
                        self._sectionEditor.check_validity()
                    except ValueError as ex:
                        self._ui.show_error(
                            message=_('Invalid changes'),
                            detail=str(ex),
                            parent=self,
                        )
                        self.lift()
                        return False

                    self._transfer_text(sectionText)
        return True

    def _create_section(self, event=None):
        if self._ctrl.isLocked:
            self._ui.show_info(
                message=_('Cannot create section'),
                detail=f"{_('The project is locked')}.",
                title=FEATURE,
                parent=self
                )
            self.lift()
            return

        self.lift()
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        return newId

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self._request_closing()
            self._service.open_editor_window()

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self._request_closing()
            self._service.open_editor_window()

    def _load_section(self):
        self.title(
            f'{self._section.title} - {self._mdl.novel.title}'
            f', {_("Section")} ID {self._scId}'
        )
        self._sectionEditor.set_text(self._section.sectionContent)

    def _open_help(self, event=None):
        NveditorHelp.open_help_page()

    def _request_closing(self, event=None):
        self._service.close_editor_window(self._scId)

    def _change_editor_colors(self):
        cm = EditorView.colorModeVar.get()
        (
            __,
            prefs['color_fg'],
            prefs['color_bg'],
            prefs['color_xml_tag'],
        ) = self.COLOR_MODES[cm]
        self._set_editor_colors()

    def _set_editor_colors(self):
        self._sectionEditor['fg'] = prefs['color_fg']
        self._sectionEditor['bg'] = prefs['color_bg']
        self._sectionEditor['insertbackground'] = prefs['color_fg']
        self._sectionEditor.tag_configure(
            self._sectionEditor.XML_TAG,
            foreground=prefs['color_xml_tag'],
        )

    def _split_section(self, event=None):

        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                message=_('Invalid changes'),
                detail=str(ex),
                parent=self,
            )
            self.lift()
            return

        if self._ctrl.isLocked:
            self._ui.show_info(
                message=_('Cannot split the section'),
                detail=f"{_('The project is locked')}.",
                title=FEATURE,
                parent=self,
            )
            self.lift()
            return

        try:
            ET.fromstring(f"<a>{self._sectionEditor.get('1.0', 'insert')}</a>")
            ET.fromstring(f"<a>{self._sectionEditor.get('insert', 'end')}</a>")
        except:
            self._ui.show_error(
                message=_('Cannot split the section at the cursor position'),
                detail=f"{_('The result would not be well-formed XML')}.",
                parent=self,
            )
            self.lift()
            return

        if self._ui.ask_yes_no(
            message=_('Move the text from the cursor position to the end into a new section?'),
            title=FEATURE,
            parent=self,
        ):
            self.lift()
        else:
            self.lift()
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_new_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self._sectionEditor.get_text(
                'insert',
                'end'
            ).strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            self._mdl.novel.sections[newId].viewpoint = (
                self._mdl.novel.sections[self._scId].viewpoint
            )

            self._load_next()

    def _transfer_text(self, sectionText):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_error(
                message=_('Invalid changes'),
                detail=str(ex),
                parent=self,
            )
            self.lift()
            return

        if self._ctrl.isLocked:
            if self._ui.ask_yes_no(
                message=_('Unlock and apply changes?'),
                detail=_('Cannot apply section changes as long as the project is locked.'),
                title=FEATURE,
                parent=self,
            ):
                self._ctrl.unlock()
                self._section.sectionContent = sectionText
            self.lift()
        else:
            self._section.sectionContent = sectionText

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MAJOR_MARKER = _('Major Character')
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
TIMETABLE_SUFFIX = '_tt_tmp'
XREF_SUFFIX = '_xref'

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr



class EditorService(SubController, Observer):
    INI_FILENAME = 'editor.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        win_geometry='600x800',
        color_mode=0,
        color_bg='white',
        color_fg='black',
        color_xml_tag='blue',
        editor_font=DEFAULT_FONT,
        font_size=12,
        line_spacing=4,
        paragraph_spacing=4,
        margin_x=40,
        margin_y=20,
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        prefs.update(self.configuration.settings)
        prefs.update(self.configuration.options)

        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self.icon = tk.PhotoImage(file=f'{path}/icons/{ICON}.png')
        except:
            self.icon = None

        self._sectionEditors = {}

        self._mdl.add_observer(self)

        EditorView.colorModeVar = tk.IntVar(
            value=int(prefs['color_mode']),
        )
        EditorBox.colorXmlTag = prefs['color_xml_tag']

    def close_editor_window(self, nodeId):
        try:
            if self._sectionEditors[nodeId].isOpen:
                self._sectionEditors[nodeId].on_quit()
            del self._sectionEditors[nodeId]
        except KeyError:
            pass

    def on_close(self):
        for scId in self._sectionEditors:
            if self._sectionEditors[scId].isOpen:
                self._sectionEditors[scId].on_quit()

    def on_quit(self):
        self.on_close()
        prefs['color_mode'] = EditorView.colorModeVar.get()

        for keyword in prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = prefs[keyword]
        self.configuration.write()

    def open_editor_window(self):
        try:
            nodeId = self._ui.selectedNode
            if nodeId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[nodeId].scType > 1:
                    return

                if self._ctrl.isLocked:
                    self._ui.show_info(
                        message=_('Cannot edit sections'),
                        detail=f"{_('The project is locked')}.",
                        title=FEATURE,
                    )
                    return

                if (nodeId in self._sectionEditors
                    and self._sectionEditors[nodeId].isOpen
                ):
                    self._sectionEditors[nodeId].lift()
                    return

                self._sectionEditors[nodeId] = EditorView(
                    self._mdl,
                    self._ui,
                    self._ctrl,
                    nodeId,
                    self,
                    icon=self.icon
                )

        except IndexError:
            pass

    def refresh(self):
        for scId in list(self._sectionEditors):
            if not scId in self._mdl.novel.sections:
                if self._sectionEditors[scId].isOpen:
                    self._sectionEditors[scId].on_quit()
                del self._sectionEditors[scId]
from abc import ABC, abstractmethod
from pathlib import Path



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon


class Plugin(PluginBase):
    VERSION = '5.10.2'
    API_VERSION = '5.50'
    DESCRIPTION = 'A multi-section "plain text" editor'
    URL = 'https://github.com/peter88213/nv_editor'

    def install(self, model, view, controller):
        """Add a submenu to the main menu.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.editorService = EditorService(model, view, controller)
        self._icon = self._get_icon('editor.png')


        self._ui.sectionMenu.add_separator()

        label = _('Edit')
        self._ui.sectionMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self._open_editor_window,
        )
        self._ui.sectionMenu.disableOnLock.append(label)

        self._ui.sectionContextMenu.add_separator()
        self._ui.sectionContextMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            accelerator=KEYS.START_EDITOR[1],
            command=self._open_editor_window,
        )
        self._ui.sectionContextMenu.disableOnLock.append(label)

        label = _('Editor plugin Online help')
        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=self._open_help,
        )

        self._ui.tv.tree.bind(KEYS.START_EDITOR[0], self._open_editor_window)

    def on_close(self, event=None):
        self.editorService.on_close()

    def on_quit(self, event=None):
        self.editorService.on_quit()

    def _open_editor_window(self, event=None):
        self.editorService.open_editor_window()

    def _open_help(self, event=None):
        NveditorHelp.open_help_page()

